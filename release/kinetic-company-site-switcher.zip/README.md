A browser extension that will change the Epicor Kinetic company and site and reload the page
